import { app, gameScene, deltaTime } from './main.js';
"use strict"